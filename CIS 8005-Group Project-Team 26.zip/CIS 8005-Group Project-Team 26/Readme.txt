Project: Well Being Prediction Analysis

Link:
https://colab.research.google.com/drive/1Z0dhMej-cCizoWVjelaFdBZwIsTKs6Uc?usp=sharing
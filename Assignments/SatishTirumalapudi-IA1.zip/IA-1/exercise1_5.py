#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 1.5
#Question: Write a program that displays the result of  9.5 × 4.5 − 2.5 × 3/45.5 − 3.5

######################
print((9.5*4.5-2.5*3)/(45.5-3.5))
#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 5.4

######################

#Miles to Kilometeres 

print("Miles   ","Kilometers")
for i in range (1,11):
    print(i,"      ",i*1.609)

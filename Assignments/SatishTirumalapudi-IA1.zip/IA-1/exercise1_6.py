#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 1.6
#Question: Write a program that displays the result of (1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9).

######################
sum=0
for x in range(1,10):
    sum=sum+x
print(sum)
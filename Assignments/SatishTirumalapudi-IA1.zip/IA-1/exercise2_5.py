#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 2.5
######################
subtotal=int(input("Please enter the Subtotal"))
gr=int(input("Please enter the gratuity rate"))
gratuity=gr/subtotal

total=gratuity+subtotal

print("The gratuity is",gratuity)

print("The total is",total)
#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 2.4
######################
p=float(input("Enter a value in pounds :"))
k=p*0.454
print("The value in Kgs:",k)

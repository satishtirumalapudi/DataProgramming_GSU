#Name :Satish Tirumalapudi
#E-mail:stirumalapudi1@student.gsu.edu
#problem :Excercise 4.23

######################
#Corresponding grades to numbers
ch=input("Please enter a character:")

ch1=ch.lower()

if ch1=='a':
    print("The Corresponding grade for value entered is 4")
elif ch1=='b':
    print("The Corresponding grade for value entered is 3")
elif ch1=='c':
    print("The Corresponding grade for value entered is 2")
elif ch1=='d':
    print("The Corresponding grade for value entered is 1")
elif ch1=="f":
    print("The Corresponding grade for value entered is 0")
else:
    print("Please enter the correct Grade")
